char c; int x1,x_2; float y1,y2;x1=5;x_2= 10;y1=2.5+x1*45;y2=100.o5-x_2/3;if(y1<=y2)c='y';else c='n';
